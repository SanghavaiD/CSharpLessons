﻿public enum MovieRating
{
    VeryBad = 0,
    Bad = 1,
    Average = 2,
    Good = 3,
    Excellant = 4
}
public enum CarColor
{
    Black = 0, White = 1, Red = 2, Green = 3
}

public enum Deserts
{
    Icecream, Cake, MysorePak
}
