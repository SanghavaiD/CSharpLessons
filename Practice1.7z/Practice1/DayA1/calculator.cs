﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice1.DayOne
{
    internal class calculator
    {
        public static int Add(int p1,int p2)
        {
            return p1+p2;
        }
        public static int Sub(int p1, int p2) 
        {
            return p1-p2;
        }
        public static int Multiply(int p1, int p2)
        {
            return p1*p2;
        }
        public static int Divide(int p1, int p2)
        {
            return p1/p2;
        }
    }

}

